// DAFTAR KUNCI + DURASI - INI YANG NGATUR TIMER
const daftarKunci = {
  // PAKET A - PEMULA (2 Jam)
  "BNG-A-01": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-02": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-03": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-04": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-05": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  
  // PAKET B - DALEM (3 Jam)
  "BNG-B-01": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-02": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-03": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-04": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-05": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  // PAKET C - SANTAI (3 Jam)
  "BNG-C-01": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-02": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-03": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-04": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-05": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-06": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-07": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-08": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-09": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-10": { paket: "PAKET C - SANTAI", durasiMenit: 180 },

  // PAKET D - MAKSIMAL (30 Hari)
  "BNG-D-01": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-02": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-03": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-04": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-05": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
};
function loginBengong(){
  const wa = document.getElementById('inputWA').value.trim();
  const kunci = document.getElementById('inputKunci').value.trim().toUpperCase();
  const errorEl = document.getElementById('pesanError');
  if(!wa || !kunci){ errorEl.innerText = "Isi WA + Kunci dulu bro!"; return; }
  if(!daftarKunci[kunci]){ errorEl.innerText = "Kunci salah bro!"; return; }
  localStorage.setItem('bengongLogin','sudah');
  localStorage.setItem('bengongWA',wa);
  localStorage.setItem('bengongKunci',kunci);
  localStorage.setItem('bengongPaket',daftarKunci[kunci].paket);
  localStorage.setItem('bengongMulai',Date.now().toString());
  localStorage.setItem('bengongDurasi',daftarKunci[kunci].durasiMenit.toString());
  window.location.href='ruang.html';
}
function logoutBengong(){
  // Simpen dulu catatan + bakar biar gak ilang pas logout
  const simpenan = {};
  for(let i=0; i<localStorage.length; i++){
    const k = localStorage.key(i);
    if(k.startsWith('catatan_') || k === 'bakarCount'){
      simpenan[k] = localStorage.getItem(k);
    }
  }
  localStorage.clear();
  // Balikin lagi catatannya
  for(const k in simpenan){
    localStorage.setItem(k, simpenan[k]);
  }
  window.location.href='index.html';
}
function cekLogin(){ if(localStorage.getItem('bengongLogin')!=='sudah'){ window.location.href='index.html'; } }
function simpanCatatan(){
  const t=document.getElementById('catatan').value;
  localStorage.setItem('catatan_'+localStorage.getItem('bengongWA'),t);
  document.getElementById('statusSimpan').innerText="✅ Tersimpan";
}