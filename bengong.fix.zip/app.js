// DAFTAR KUNCI + DURASI - INI YANG NGATUR TIMER
// --- DATA BUKU LITTLE PRINCE - 27 BAB, TIAP BAB ADA HALAMAN ---
export const MAP_PAKET = {
  A: { nama: "PAKET A - 2 JAM", menit: 120, maxBuku: 13, maxBab: 5 },
  B: { nama: "PAKET B - 3 JAM", menit: 180, maxBuku: 13, maxBab: 13 },
  C: { nama: "PAKET C - SAMPE SHUBUH", menit: 300, maxBuku: 13, maxBab: 20 },
  S: { nama: "PAKET S - SAMPE SEBULAN", menit: 43200, maxBuku: 13, maxBab: 27 },
  D: { nama: "PAKET S - SAMPE SEBULAN", menit: 43200, maxBuku: 13, maxBab: 27 }
};
export function getNextPaket(h){
  if(h==='A') return 'PAKET B';
  if(h==='B') return 'PAKET C';
  if(h==='C') return 'PAKET S';
  return 'PAKET S';
}

export const BUKU_LITTLE_PRINCE = {
  bab: [
    { judul: "Bab 1", halaman: ["Bab 1 Hal 1: Aku dulu umur 6 tahun gambar ular boa nelan gajah.", "Bab 1 Hal 2: Gedean jadi pilot, pesawat rusak di Sahara.", "Bab 1 Hal 3: Ada suara kecil: Tolong gambarin aku domba. Itu Pangeran Kecil."] },
    { judul: "Bab 2", halaman: ["Bab 2 Hal 1", "Bab 2 Hal 2"] },
    { judul: "Bab 3", halaman: ["Bab 3 Hal 1", "Bab 3 Hal 2", "Bab 3 Hal 3"] },
    { judul: "Bab 4", halaman: ["Bab 4 Hal 1"] },
    { judul: "Bab 5", halaman: ["Bab 5 Hal 1"] },
    { judul: "Bab 6", halaman: ["Bab 6 Hal 1"] },
    { judul: "Bab 7", halaman: ["Bab 7 Hal 1"] },
    { judul: "Bab 8", halaman: ["Bab 8 Hal 1"] },
    { judul: "Bab 9", halaman: ["Bab 9 Hal 1"] },
    { judul: "Bab 10", halaman: ["Bab 10 Hal 1"] },
    { judul: "Bab 11", halaman: ["Bab 11 Hal 1"] },
    { judul: "Bab 12", halaman: ["Bab 12 Hal 1"] },
    { judul: "Bab 13", halaman: ["Bab 13 Hal 1"] },
    { judul: "Bab 14", halaman: ["Bab 14 Hal 1"] },
    { judul: "Bab 15", halaman: ["Bab 15 Hal 1"] },
    { judul: "Bab 16", halaman: ["Bab 16 Hal 1"] },
    { judul: "Bab 17", halaman: ["Bab 17 Hal 1"] },
    { judul: "Bab 18", halaman: ["Bab 18 Hal 1"] },
    { judul: "Bab 19", halaman: ["Bab 19 Hal 1"] },
    { judul: "Bab 20", halaman: ["Bab 20 Hal 1"] },
    { judul: "Bab 21", halaman: ["Bab 21 Hal 1"] },
    { judul: "Bab 22", halaman: ["Bab 22 Hal 1"] },
    { judul: "Bab 23", halaman: ["Bab 23 Hal 1"] },
    { judul: "Bab 24", halaman: ["Bab 24 Hal 1"] },
    { judul: "Bab 25", halaman: ["Bab 25 Hal 1"] },
    { judul: "Bab 26", halaman: ["Bab 26 Hal 1"] },
    { judul: "Bab 27", halaman: ["Bab 27 Hal 1"] }
  ]
};

export function getNextPaket(h){ 
  if(h==='A') return 'B';
  if(h==='B') return 'C';
  return 'D';
}
export function cekLogin(){
  const sesi = JSON.parse(localStorage.getItem('bengongSesi'));
  if(!sesi){ return null; }
  return sesi;
}

export function getNextPaket(huruf) {
  const urutan = ['A','B','C','D'];
  return urutan[urutan.indexOf(huruf)+1] || 'D';
}
const daftarKunci = {
  // PAKET A - PEMULA (2 Jam)
  "BNG-A-01": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-02": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-03": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-04": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-05": { paket: "PAKET A - PEMULA", durasiMenit: 120 },

  // PAKET B - DALEM (3 Jam)
  "BNG-B-01": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-02": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-03": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-04": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-05": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  // PAKET C - SANTAI (3 Jam)
  "BNG-C-01": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-02": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-03": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-04": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-05": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-06": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-07": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-08": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-09": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-10": { paket: "PAKET C - SANTAI", durasiMenit: 180 },

  // PAKET D - MAKSIMAL (30 Hari)
  "BNG-D-01": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-02": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-03": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-04": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-05": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
};
// Taruh config yang tadi lo copy dari admin.html di sini
const firebaseConfig = {
  apiKey: "AIzaSyCPVCixu3Lz8NyhgyouZRrArCLeajgIcTLA",
  authDomain: "bengong-id.firebaseapp.com",
  projectId: "bengong-id",
  storageBucket: "bengong-id.firebasestorage.app",
  messagingSenderId: "186332173874",
  appId: "1:186332173874:web:70d3f4a6ba27363f00be2b",
  measurementId: "G-ZN3L5GRNZZ"
};

let dbFirebase = null;
async function getDB() {
  if (dbFirebase) return dbFirebase;
  const { initializeApp } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js");
  const { getFirestore } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js");
  const app = initializeApp(firebaseConfig);
  dbFirebase = getFirestore(app);
  return dbFirebase;
}

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
function setError(pesan) {
  const el = document.getElementById('pesanError');
  if (el) el.innerText = pesan;
  console.log(pesan);
}

function setLoading(isLoading) {
  const btn = document.querySelector('button[onclick="loginBengong()"]');
  if (!btn) return;
  if (isLoading) {
    btn.dataset.asli = btn.innerText;
    btn.innerText = "SABAR...";
    btn.disabled = true;
  } else {
    btn.innerText = btn.dataset.asli || "MASUK KE KAMAR SAYA";
    btn.disabled = false;
  }
}

// ... firebaseConfig lu biarin ...

async function loginBengong() {
  const kunci = document.getElementById('inputKunci').value.trim().toUpperCase();
  const wa = document.getElementById('inputWA').value.trim();
  if (!kunci || !wa) {
    setError("Isi kunci + WA dulu bro!");
    return;
  }

  setLoading(true);

    try {
    const db = await getDB();
    // 1. CARI BY FIELD 'kode'...
    // 1. CARI BY FIELD 'kode', BUKAN BY ID DOKUMEN
    const q = query(collection(db, "pesanan"), where("kode", "==", kunci));
    const querySnap = await getDocs(q);

    if (querySnap.empty) {
      setError("Kunci gak ketemu / belum diverifikasi admin!");
      setLoading(false);
      return;
    }

    const docData = querySnap.docs[0];
    const data = docData.data();

    if (data.status !== "DITERIMA") {
      setError("Kunci belum aktif, tunggu verifikasi admin!");
      setLoading(false);
      return;
    }

    // 2. INI FIX UTAMA - JANGAN PERCAYA data.paket, PERCAYA HURUF KUNCI
    const huruf = kunci.split('-')[2]; // BNG-2811-B-003 -> B

    const MAP_PAKET = {
      A: { paket: "PAKET A - PEMULA", menit: 120 },
      B: { paket: "PAKET B - DALEM", menit: 180 },
      C: { paket: "PAKET C - SAMPE SUBUH", menit: 300 },
      D: { paket: "PAKET D - MAKSIMAL", menit: 43200 }
    };

    const info = MAP_PAKET[huruf];
    if (!info) {
      setError("Format kunci salah bro!");
      setLoading(false);
      return;
    }

    // 3. SIMPAN SESI YANG BENER
    const sesi = {
      kunci: kunci,
      wa: wa,
      paket: info.paket, // PASTI D kalo kuncinya D
      durasiMenit: info.menit,
      mulai: null,
      sudahMulai: false
    };

    localStorage.setItem('bengongSesi', JSON.stringify(sesi));
    window.location.href = "ruang.html";

  } catch (e) {
    setError("Error: " + e.message);
  }
  setLoading(false);
}

window.loginBengong = loginBengong;

function logoutBengong() {
  // Simpen dulu catatan + bakar biar gak ilang pas logout
  const simpenan = {};
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k.startsWith('catatan_') || k === 'bakarCount') {
      simpenan[k] = localStorage.getItem(k);
    }
  }
  localStorage.clear();
  // Balikin lagi catatannya
  for (const k in simpenan) {
    localStorage.setItem(k, simpenan[k]);
  }
  window.location.href = 'index.html';
}
export function cekLogin() {
  // kalau di halaman login, jangan ditendang
  if (window.location.pathname.includes("index.html") || window.location.pathname === "/") {
    return;
  }
  const sesi = JSON.parse(localStorage.getItem('bengongSesi'));
  const loginLama = localStorage.getItem('bengongLogin');
  
  if (!sesi && loginLama !== 'sudah') {
    window.location.href = 'index.html';
    return;
  }
  
  // INI YANG BIKIN BNG-2811-B-003 JADI PAKET B
  if (sesi && sesi.kunci) {
    const parts = sesi.kunci.split('-'); // ["BNG","2811","B","003"]
    const huruf = parts[2] || 'B'; // ambil huruf B nya
    sesi.paketHuruf = huruf;
    localStorage.setItem('bengongSesi', JSON.stringify(sesi));
  }
}
function simpanCatatan() {
  const t = document.getElementById('catatan').value;
  localStorage.setItem('catatan_' + localStorage.getItem('bengongWA'), t);
  document.getElementById('statusSimpan').innerText = "✅ Tersimpan";
}
// SAMBUNGIN TOMBOL LOGIN
document.addEventListener("DOMContentLoaded", function () {
  let tombol = document.getElementById("btnMasukKamar");
  if (tombol) {
    tombol.addEventListener("click", loginBengong);
  } else {
    console.log("TOMBOL GAK KETEMU, CEK ID NYA!");
  }
});