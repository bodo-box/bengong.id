// musik.js - bengong.id - 10 Musik Tanpa MP3 - FIX PAKET B
let audioCtx, master, noiseNode, jangkrikTimer = null;

function initAudio(){
  if(audioCtx) return;
  audioCtx = new (window.AudioContext||window.webkitAudioContext)();
  master = audioCtx.createGain(); master.gain.value = 0.8; master.connect(audioCtx.destination);
}

function stopBengong(){
  if(jangkrikTimer){ clearInterval(jangkrikTimer); jangkrikTimer = null; }
  try{ if(noiseNode) noiseNode.stop(); }catch(e){}
  noiseNode = null;
}

function makeNoise(){
  let len = audioCtx.sampleRate * 2;
  let buf = audioCtx.createBuffer(1, len, audioCtx.sampleRate);
  let d = buf.getChannelData(0);
  for(let i=0;i<len;i++) d[i]=Math.random()*2-1;
  let src = audioCtx.createBufferSource(); src.buffer=buf; src.loop=true; return src;
}

function playBengong(mode){
  initAudio(); stopBengong();
  if(audioCtx.state==='suspended') audioCtx.resume();

  // Hening Total = emang sengaja diem
  if(mode==='hening') return;

  // JANGKRIK / JENGKERIK - support 2 nama biar gak salah lagi
  if(mode==='jangkrik' || mode==='jengkerik'){
    jangkrikTimer = setInterval(()=>{
      for(let k=0;k<3;k++){
        setTimeout(()=>{
          let o = audioCtx.createOscillator(); o.frequency.value=4200; o.type='sine';
          let g = audioCtx.createGain();
          let t = audioCtx.currentTime;
          g.gain.setValueAtTime(0, t);
          g.gain.linearRampToValueAtTime(0.25, t+0.03);
          g.gain.linearRampToValueAtTime(0, t+0.15);
          o.connect(g); g.connect(master); o.start(t); o.stop(t+0.2);
        }, k*120);
      }
    }, 900);
    return;
  }

  let src = makeNoise();
  let filter = audioCtx.createBiquadFilter();
  let gain = audioCtx.createGain();

  // SEMUA 10 MUSIK - VOLUME UDAH GUE GEDEIN
  if(mode==='hujan'){ filter.type='bandpass'; filter.frequency.value=800; gain.gain.value=0.9; }
  if(mode==='hujan-deras'){ filter.type='bandpass'; filter.frequency.value=1200; gain.gain.value=1.2; }
  if(mode==='kipas'){ filter.type='lowpass'; filter.frequency.value=400; gain.gain.value=0.8; }
  if(mode==='warung'){ filter.type='bandpass'; filter.frequency.value=500; gain.gain.value=0.6; }
  if(mode==='laut'){ filter.type='lowpass'; filter.frequency.value=600; gain.gain.value=0.9; }
  if(mode==='angin'){ filter.type='bandpass'; filter.frequency.value=300; gain.gain.value=0.8; }
  if(mode==='api'){ filter.type='lowpass'; filter.frequency.value=900; gain.gain.value=0.7; }
  if(mode==='kereta'){ filter.type='lowpass'; filter.frequency.value=200; gain.gain.value=0.9; }

  src.connect(filter); filter.connect(gain); gain.connect(master); src.start(); noiseNode=src;
}