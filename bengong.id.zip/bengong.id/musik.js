// musik.js - Bengong.id - Musik dibuat dari browser, tanpa file mp3
// Cara pakai: <script src="musik.js"></script> lalu panggil playBengong('hujan')

let audioCtx = null;
let nodes = [];
let currentMusik = null;

function stopBengong() {
  nodes.forEach(n => {
    try { n.stop ? n.stop() : null; } catch(e){}
    try { n.disconnect(); } catch(e){}
  });
  nodes = [];
  if (audioCtx) audioCtx.close();
  audioCtx = null;
  currentMusik = null;
}

function buatNoise() {
  let bufferSize = audioCtx.sampleRate * 2;
  let buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
  let data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = Math.random() * 2 - 1;
  }
  let source = audioCtx.createBufferSource();
  source.buffer = buffer;
  source.loop = true;
  return source;
}

function playBengong(jenis) {
  stopBengong();
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  currentMusik = jenis;

  let gain = audioCtx.createGain();
  gain.gain.value = 0.35;
  gain.connect(audioCtx.destination);

  if (jenis === 'hujan') {
    let noise = buatNoise();
    let filter = audioCtx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 1200;
    noise.connect(filter);
    filter.connect(gain);
    noise.start();
    nodes.push(noise);

    setInterval(() => {
      if (currentMusik !== 'hujan') return;
      let osc = audioCtx.createOscillator();
      let g = audioCtx.createGain();
      osc.frequency.value = 1800 + Math.random() * 1200;
      g.gain.value = 0.02;
      g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.08);
      osc.connect(g); g.connect(gain);
      osc.start(); osc.stop(audioCtx.currentTime + 0.09);
    }, 180);

  } else if (jenis === 'kipas') {
    let osc = audioCtx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = 65;
    let lfo = audioCtx.createOscillator();
    lfo.frequency.value = 0.7;
    let lfoGain = audioCtx.createGain();
    lfoGain.gain.value = 12;
    lfo.connect(lfoGain); lfoGain.connect(osc.frequency);
    osc.connect(gain);
    osc.start(); lfo.start();
    nodes.push(osc, lfo);

    let noise = buatNoise();
    let filter = audioCtx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 400;
    let g2 = audioCtx.createGain(); g2.gain.value = 0.08;
    noise.connect(filter); filter.connect(g2); g2.connect(gain);
    noise.start(); nodes.push(noise);

  } else if (jenis === 'warung') {
    let noise = buatNoise();
    let filter = audioCtx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 800;
    let g2 = audioCtx.createGain(); g2.gain.value = 0.12;
    noise.connect(filter); filter.connect(g2); g2.connect(gain);
    noise.start(); nodes.push(noise);

    setInterval(() => {
      if (currentMusik !== 'warung') return;
      let osc = audioCtx.createOscillator();
      osc.frequency.value = 2400 + Math.random() * 800;
      let g = audioCtx.createGain();
      g.gain.value = 0.05;
      g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.25);
      osc.connect(g); g.connect(gain);
      osc.start(); osc.stop(audioCtx.currentTime + 0.3);
    }, 3200);

  } else if (jenis === 'laut') {
    let noise = buatNoise();
    let filter = audioCtx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 500;
    let lfo = audioCtx.createOscillator();
    lfo.frequency.value = 0.12;
    let lfoGain = audioCtx.createGain();
    lfoGain.gain.value = 300;
    lfo.connect(lfoGain); lfoGain.connect(filter.frequency);
    noise.connect(filter); filter.connect(gain);
    noise.start(); lfo.start();
    nodes.push(noise, lfo);
  }

  console.log('Bengong.id - lagi main musik:', jenis);
}

window.playBengong = playBengong;
window.stopBengong = stopBengong;