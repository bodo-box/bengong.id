// DAFTAR KUNCI + DURASI - INI YANG NGATUR TIMER
const daftarKunci = {
  // PAKET A - PEMULA (2 Jam)
  "BNG-A-01": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-02": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-03": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-04": { paket: "PAKET A - PEMULA", durasiMenit: 120 },
  "BNG-A-05": { paket: "PAKET A - PEMULA", durasiMenit: 120 },

  // PAKET B - DALEM (3 Jam)
  "BNG-B-01": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-02": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-03": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-04": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  "BNG-B-05": { paket: "PAKET B - DALEM", durasiMenit: 180 },
  // PAKET C - SANTAI (3 Jam)
  "BNG-C-01": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-02": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-03": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-04": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-05": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-06": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-07": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-08": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-09": { paket: "PAKET C - SANTAI", durasiMenit: 180 },
  "BNG-C-10": { paket: "PAKET C - SANTAI", durasiMenit: 180 },

  // PAKET D - MAKSIMAL (30 Hari)
  "BNG-D-01": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-02": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-03": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-04": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
  "BNG-D-05": { paket: "PAKET D - MAKSIMAL", durasiMenit: 43200 },
};
// Taruh config yang tadi lo copy dari admin.html di sini
const firebaseConfig = {
  apiKey: "AIzaSyCPVCixu3Lz8NyhgyouZRrArCLeajgIcTLA",
  authDomain: "bengong-id.firebaseapp.com",
  projectId: "bengong-id",
  storageBucket: "bengong-id.firebasestorage.app",
  messagingSenderId: "186332173874",
  appId: "1:186332173874:web:70d3f4a6ba27363f00be2b",
  measurementId: "G-ZN3L5GRNZZ"
};

let dbFirebase = null;
async function getDB() {
  if (dbFirebase) return dbFirebase;
  const { initializeApp } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js");
  const { getFirestore } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js");
  const app = initializeApp(firebaseConfig);
  dbFirebase = getFirestore(app);
  return dbFirebase;
}

async function loginBengong() {
  const wa = document.getElementById("inputWA").value.trim();
  const kunci = document.getElementById("inputKunci").value.trim().toUpperCase();
  const errorEl = document.getElementById("errorMsg");
  function setError(pesan) { if (errorEl) errorEl.innerText = pesan; else if (pesan) alert(pesan); }
  setError("");

  if (!wa || !kunci) { setError("Isi WA dan Kunci dulu bro!"); return; }
  try {
    const db = await getDB();
    const { collection, query, where, getDocs } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js");

    const q = query(collection(db, "pesanan"), where("kode", "==", kunci), where("wa", "==", wa));
    const snap = await getDocs(q);

    if (snap.empty) {
      setError("Kunci salah bro! WA / Kunci gak cocok");
      return;
    }

    const data = snap.docs[0].data();

    if (data.status !== "DITERIMA") {
      errorEl.innerText = "Pesanan lo belum diverifikasi admin bro, tunggu ya!";
      return;
    }

  let durasiMenit = 120;
let k = kunci.toUpperCase().trim();
if (k.includes("BNG-A")) durasiMenit = 120;
else if (k.includes("BNG-B")) durasiMenit = 180;
else if (k.includes("BNG-C")) durasiMenit = 300;
else if (k.includes("BNG-D")) durasiMenit = 43200;

   const sesi = { 
  kunci: kunci, 
  wa: wa, 
  paket: data.paket || "PAKET D", 
  mulai: null, // BELUM MULAI, nunggu di klik di ruang.html
  durasiMenit: durasiMenit,
  sudahMulai: false 
};
localStorage.setItem("bengongSesi", JSON.stringify(sesi));
localStorage.setItem("bengongLogin", "sudah");
localStorage.setItem("bengongWA", wa);
localStorage.removeItem("waktuHabis");
window.location.href = "ruang.html";
  } catch (e) {
    console.error(e);
    setError("Gagal konek ke server bro, coba lagi!");
  }
}
function logoutBengong() {
  // Simpen dulu catatan + bakar biar gak ilang pas logout
  const simpenan = {};
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k.startsWith('catatan_') || k === 'bakarCount') {
      simpenan[k] = localStorage.getItem(k);
    }
  }
  localStorage.clear();
  // Balikin lagi catatannya
  for (const k in simpenan) {
    localStorage.setItem(k, simpenan[k]);
  }
  window.location.href = 'index.html';
}
function cekLogin() {
  // Kalo masih di halaman login, jangan ditendang
  if (window.location.pathname.includes("index.html") || window.location.pathname === "/" ) {
    return;
  }
  if (localStorage.getItem('bengongLogin') !== 'sudah') {
    window.location.href = 'index.html';
  }
}
function simpanCatatan() {
  const t = document.getElementById('catatan').value;
  localStorage.setItem('catatan_' + localStorage.getItem('bengongWA'), t);
  document.getElementById('statusSimpan').innerText = "✅ Tersimpan";
}
// SAMBUNGIN TOMBOL LOGIN
document.addEventListener("DOMContentLoaded", function() {
  let tombol = document.getElementById("btnMasukKamar");
  if (tombol) {
    tombol.addEventListener("click", loginBengong);
  } else {
    console.log("TOMBOL GAK KETEMU, CEK ID NYA!");
  }
});